#!/bin/ksh
cd XBTWEB

source .venv-xbt/bin/activate

python make_db.py

python make_web.py

python send_website.py

deactivate
