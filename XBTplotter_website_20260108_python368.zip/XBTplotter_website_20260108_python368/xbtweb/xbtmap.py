import folium
from branca.element import MacroElement
from folium.elements import JSCSSMixin
from jinja2 import Template
import random
import os
import posixpath
from urllib.parse import quote
from collections import defaultdict
from datetime import datetime as dt

# --- START BACKPORT: GroupedLayerControl for Folium 0.13.0 / Python 3.6 ---
class GroupedLayerControl(JSCSSMixin, MacroElement):
    _template = Template(
        """
        {% macro script(this, kwargs) %}
            var groupedOverlays = {
            {%- for group_name, layers in this.grouped_overlays.items() %}
                {{ group_name|tojson }}: {
                    {%- for layer in layers %}
                        {{ layer.layer_name|tojson }}: {{ layer.get_name() }}
                        {%- if not loop.last %},{% endif %}
                    {%- endfor %}
                }
                {%- if not loop.last %},{% endif %}
            {%- endfor %}
            };

            var options = {
                exclusiveGroups: {{ this.exclusive_groups|tojson }},
                groupCheckboxes: {{ this.group_checkboxes|tojson }},
                collapsed: {{ this.collapsed|tojson }} 
            };

            L.control.groupedLayers(
                {{ this.base_layers|tojson }},
                groupedOverlays,
                options
            ).addTo({{ this._parent.get_name() }});
        {% endmacro %}
        """
    )
    default_js = [
        ("leaflet.groupedlayercontrol.min.js", "https://cdnjs.cloudflare.com/ajax/libs/leaflet-groupedlayercontrol/0.6.1/leaflet.groupedlayercontrol.min.js"),
    ]
    default_css = [
        ("leaflet.groupedlayercontrol.min.css", "https://cdnjs.cloudflare.com/ajax/libs/leaflet-groupedlayercontrol/0.6.1/leaflet.groupedlayercontrol.min.css"),
    ]

    def __init__(self, base_layers=None, grouped_overlays=None, exclusive_groups=False, group_checkboxes=True, collapsed=True, **kwargs):
        super().__init__(**kwargs)
        self._name = "GroupedLayerControl"
        self.base_layers = base_layers or {}
        self.grouped_overlays = grouped_overlays or {}
        self.exclusive_groups = exclusive_groups
        self.group_checkboxes = group_checkboxes
        self.collapsed = collapsed
# --- END BACKPORT ---


def make_xbt_map(dict_list, outputParentDir, map_subdir, plots_subdir, json_subdir, fname):
    init_pos = [20.416501, -69.914840]
    full_map = folium.Map(location=init_pos, zoom_start=6)

    # Structure: {'Year_String': [FeatureGroup1, FeatureGroup2, ...]}
    grouped_overlays = defaultdict(list)

    # Track created layers to avoid duplicates
    created_layers = {}

    # Initialize previous values for color logic
    soopLine_prev = ""
    callSign_prev = ""
    transectNumber_prev = ""
    datetime_prev = "2000-01-01 00:00:00"

    dtnow = dt.now() 
    
    # ---------------------------------------------------------
    # 1. PROCESS PROFILES AND CREATE LAYERS
    # ---------------------------------------------------------
    for dict_item in dict_list:           
        latitude = dict_item["latitude"]
        longitude = dict_item["longitude"]
        soopLine = dict_item["soopLine"]
        transectNumber = dict_item["transectNumber"]
        callSign = dict_item["callSign"]
        datetime = dict_item["datetime"] 
        fileName = dict_item["fileName"]
        
        # Extract Year to serve as the Group Header
        profileYear = datetime[:4]

        # Define a unique key for this Year + SOOP Line combination
        layer_key = f"{profileYear}_{soopLine}"

        # Check if the FeatureGroup (Layer) for this specific Year+SOOP exists
        if layer_key not in created_layers:
            # Create a new FeatureGroup. 
            fg = folium.FeatureGroup(name=soopLine, overlay=True, show=False)
            fg.add_to(full_map)
            
            created_layers[layer_key] = fg
            grouped_overlays[profileYear].append(fg)

        # ---------------------------------------------------------
        # 2. PREPARE POPUP CONTENT
        # ---------------------------------------------------------
        plotFilename = fileName.replace(".bin", ".png")
        jsonFilename = fileName.replace(".bin", ".json")
        plots_subdir_posix = plots_subdir.replace("\\", "/").strip("/")
        json_subdir_posix = json_subdir.replace("\\", "/").strip("/")
        plotLink = posixpath.join("../../", plots_subdir_posix, plotFilename)
        jsonLink = posixpath.join("../../", json_subdir_posix, jsonFilename)
        plotLink = quote(plotLink, safe="/")
        jsonLink = quote(jsonLink, safe="/")

        # Check cruise continuity       
        if (callSign == callSign_prev) and (soopLine == soopLine_prev):
            date_obj = dt.strptime(datetime, "%Y-%m-%d %H:%M:%S")
            date_obj_prev = dt.strptime(datetime_prev, "%Y-%m-%d %H:%M:%S")
            delta_days = abs((date_obj - date_obj_prev).days)
            if delta_days <= 7:
                different_cruise = False                
            else:
                different_cruise = True
        else:
             different_cruise = True

        # Update color if key attributes change        
        if (callSign != callSign_prev) or (soopLine != soopLine_prev) or (transectNumber != transectNumber_prev) or (different_cruise == True):
            fc_r, fc_g, fc_b = generate_random_rgb_color()

        popup_text = f"callSign: {callSign}<br>position: {(latitude):.3f},{(longitude):.3f}<br>soopLine: {soopLine}<br>datetime: {datetime}<br>transectNumber: {transectNumber}<br>file: {fileName}<br><a href=\"{jsonLink}\" alt='JSON'>JSON</a>  |  <a href=\"{plotLink}\" alt='Plot'>Plot</a>"
        tip_text = f"callSign: {callSign}<br>soopLine: {soopLine} ({transectNumber})<br>datetime: {datetime}"

        fillcolor = f"rgb({fc_r},{fc_g},{fc_b})"

        # if recent cruise (within last 7 days), make marker larger
        profile_datetime_obj = dt.strptime(datetime, "%Y-%m-%d %H:%M:%S")
        days_difference = (dtnow - profile_datetime_obj).days
        if days_difference <= 7:
            radius = 8
            extcolor = "black"
        else:
            extcolor = "white"
            radius = 5
        
        # ---------------------------------------------------------
        # 3. CREATE MARKER AND ADD TO SPECIFIC LAYER
        # ---------------------------------------------------------
        obj = create_map_marker(latitude, longitude, radius, extcolor, fillcolor, popup_text, tip_text)
        obj.add_to(created_layers[layer_key])
        
        callSign_prev = callSign
        soopLine_prev = soopLine
        transectNumber_prev = transectNumber
        datetime_prev = datetime
    
    
    # ---------------------------------------------------------
    # 4. ADD GROUPED LAYER CONTROL
    # ---------------------------------------------------------
    # Add CSS to make group headers (Years) bold --- THIS STYLING LEAVE A LONG FILTER COLUMN THAT CAN BE PLACED OUT OF SCREEN
    # full_map.get_root().header.add_child(folium.Element(
        # """
        # <style>
        # .leaflet-control-layers-group-label {
            # font-weight: 900 !important;
            # color: #000;
            # background-color: #ADD8E6; /* Light Blue */
            # padding: 5px;
            
            # /* FLEXBOX FIX: Keeps checkbox and text visible and aligned */
            # display: flex;       
            # align-items: center; 
            # width: 100%;         
            # box-sizing: border-box; /* Ensures padding doesn't break the width */
        # }
        # </style>
        # """
        # ))     
        
    # Add CSS for GRID LAYOUT (Fits text perfectly) - one column filter per year
    full_map.get_root().header.add_child(folium.Element(
        """
        <style>
        /* 1. Make the container shrink to fit the content exactly */
        .leaflet-control-layers-expanded {
            width: fit-content !important; 
            max-width: 95vw; /* Prevent it from going off-screen */
        }

        /* 2. Use CSS Grid for the columns */
        .leaflet-control-layers-overlays {
            display: grid;
            
            /* Create 4 columns. 'auto' means "width of the widest text" */
            /* You can change '4' to '3' or '5' depending on preference */
            grid-template-columns: repeat(4, auto); 
            
            column-gap: 25px; /* Space between columns */
            row-gap: 10px;    /* Space between rows */
        }

        /* 3. Keep each Year group together */
        .leaflet-control-layers-group {
            break-inside: avoid;
        }

        /* 4. Styling for the Year Headers */
        .leaflet-control-layers-group-label {
            font-weight: 900 !important;
            color: #000;
            background-color: #ADD8E6; 
            padding: 5px;
            display: flex;       
            align-items: center; 
            width: 100%;         
            box-sizing: border-box;
            border-radius: 4px;
        }
        </style>
        """
        ))
    
    GroupedLayerControl(
        grouped_overlays=grouped_overlays,
        collapsed=False,
        exclusive_groups=False 
    ).add_to(full_map)

    # SAVE MAP TO HTML FILE
    xbtmap_dir_path = os.path.join(outputParentDir, map_subdir)
    os.makedirs(xbtmap_dir_path, exist_ok=True)
    xbtmap_file_path = os.path.join(xbtmap_dir_path, fname)
    full_map.save(xbtmap_file_path)
    print(f"> XBT Map saved in {xbtmap_file_path}")

def create_map_marker(lat, lon, radius, extcolor, fillcolor, popup_text, tip_text):
    popup_obj = folium.Popup(popup_text, max_width=600)
    myobj = folium.CircleMarker(
        location=[lat, lon],
        radius=radius,
        color=extcolor,
        fill=True,
        fill_color=fillcolor,
        fill_opacity=0.7,
        popup=popup_obj,
        tooltip=tip_text
    )
    return myobj

def generate_random_rgb_color():
    r = random.randint(0, 255)
    g = random.randint(0, 255)
    b = random.randint(0, 255)
    return (r, g, b)